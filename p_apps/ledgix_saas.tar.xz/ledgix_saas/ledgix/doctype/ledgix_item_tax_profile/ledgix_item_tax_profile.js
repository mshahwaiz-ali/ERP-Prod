// Copyright (c) 2026, Ali and contributors
// For license information, please see license.txt

// frappe.ui.form.on("Ledgix Item Tax Profile", {
// 	refresh(frm) {

// 	},
// });
